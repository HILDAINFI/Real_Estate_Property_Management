export interface Booking {
    buyerId: number;
    bookingId?: number; 
    sellerId: number;
    propertyId: number;
    name: string;
    email: string;
    status: string;
    date?: Date;
  }
  