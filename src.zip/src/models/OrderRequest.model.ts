export interface OrderRequest {
  customerName: string;
  amount: number;
  status:string; 
  razorpayOrderId:string;
 id:number
  userId:any;
  createdAt:Date;

}
   