import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { RouterLink } from '@angular/router';
import { CurrencyPipe } from '@angular/common';
import { PropertiesComponent } from '../properties/properties.component';
import { LoginComponent } from '../login/login.component';
import { FooterComponent } from '../footer/footer.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {
  isBuyer:boolean=false;
  userRole: string;
  isSeller: boolean;
  isAdmin: boolean;
  constructor(){
    const userRole=localStorage.getItem('userRole')
    if(this.userRole=='BUYER'){
      this.isBuyer=true
    }
    if(this.userRole=='SELLER'){
      this.isSeller=true
    }
    if(this.userRole=='ADMIN'){
      this.isAdmin=true
    }
    
  }


}
