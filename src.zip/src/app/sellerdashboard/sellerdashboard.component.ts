import { Component, OnInit } from '@angular/core';
import { Property } from '../add-property/add-property.component';
import { LoginService } from '../login.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BookingService } from '../booking.service';
import { Booking } from '../../models/Booking.model';
import { InquiryFormComponent } from '../inquiry-form/inquiry-form.component';
import { FooterComponent } from '../footer/footer.component';
import { InquiryService } from '../inquiry.service';
import { Inquiry } from '../../models/Inquiry.model';

@Component({
  selector: 'app-sellerdashboard',
  imports: [FormsModule,CommonModule,FooterComponent],
  templateUrl: './sellerdashboard.component.html',
  styleUrl: './sellerdashboard.component.css'
})
export class SellerdashboardComponent implements OnInit{


  sellerProperties: Property[] = [];
  editingProperty: Property | null = null; // Stores the property currently being edited
  originalPropertyState: Property | null = null; // To restore if cancel clicked
  editingBooking: Booking | null = null; // Stores the booking currently being edited
  originalBookingState: Booking | null = null
  isSeller=false;
 
  countOfProperties: number = 0;
  userId;
  buyerBookings: Booking[];
  userName: string;
  countofbookings: number;
  private allPropertiesMap: Map<string, string> = new Map();
  buyerInquiries: Inquiry[];
  countofInquiries: number;
  editingInquiry: null;
  editingId
  inquiries: Inquiry[];
  editableResponse: string;

  constructor(private propertyService: LoginService,private bookingService:BookingService,private inquiryService:InquiryService) {}

  ngOnInit(): void {
    this.userId = localStorage.getItem('userId') ;
    if (this.userId) {
      this.fetchSellerProperties();
      this.fetchSellerBookings();
      this.fetchSellerInquiries();
      this.loadInquiries();
      


     
     
   
  
  }

}  
fetchSellerBookings(): void {
  // Ensure userId is correctly populated before this call
  this.bookingService.getAllBookings().subscribe(
    (bookings: Booking[]) => {
      // Corrected filter syntax: no curly braces needed for single expression
      // Ensure b.sellerId and this.userId are of comparable types (e.g., both strings or both numbers)
      this.buyerBookings = bookings.filter(b => b.sellerId == this.userId);
      console.log('Filtered Bookings:', this.buyerBookings);
      this.countofbookings = this.buyerBookings.length;
    },
    error => {
      console.error('Error fetching bookings:', error);
    }
  );
}


loadInquiries() {
  this.inquiryService.getAll().subscribe(data => this.inquiries = data);
}
getInquiryById(id: number): void 
{
  this.inquiryService.getInquiryById(1).subscribe({
    next: (data) => {
      console.log('Inquiry:', data);
      // You can assign it to a variable to display in the UI
    },
    error: (err) => {
      console.error('Error fetching inquiry:', err);
    }
  });
  
}


onInquiryCreated() {
  this.loadInquiries();
}
enableEdit(inquiry: Inquiry) {
  this.editingId = inquiry.inquiryId!;
  this.editableResponse = inquiry.response || '';
}

updateResponse(inquiry: Inquiry) {
  const updated: Inquiry = { ...inquiry, response: this.editableResponse };
  this.inquiryService.updateResponse(updated).subscribe(() => {
    this.editingId = null;
    this.loadInquiries();
  });
}

cancelEdit() {
  this.editingId = null;
}

fetchSellerInquiries(): void {
  // Ensure userId is correctly populated before this call
  this.inquiryService.getAll().subscribe(
    (inquiries: Inquiry[]) => {
      // Corrected filter syntax: no curly braces needed for single expression
      // Ensure b.sellerId and this.userId are of comparable types (e.g., both strings or both numbers)
      this.buyerInquiries = inquiries.filter(m => m.sellerId == this.userId);
      console.log('Filtered inquiries:', this.buyerInquiries);
      this.countofInquiries = this.buyerInquiries.length;
    },
    error => {
      console.error('Error fetching bookings:', error);
    }
  );
}










onEditBooking(booking: Booking): void {
  this.editingBooking = { ...booking }; // Create a copy to edit
  this.originalBookingState = { ...booking }; // Store original state
}

// Called when the "Save" button is clicked for a booking
onSaveBooking(booking: Booking): void {
  if (this.editingBooking && this.editingBooking.bookingId) { // Ensure bookingId exists
    // You'll need a new updateBooking method in your BookingService
    this.bookingService.updateBookingStatus(this.editingBooking.bookingId, this.editingBooking).subscribe(
      response => {
        console.log('Booking updated successfully:', response);
        const index = this.buyerBookings.findIndex(b => b.bookingId === this.editingBooking?.bookingId);
        if (index !== -1) {
          this.buyerBookings[index] = { ...this.editingBooking }; // Update local array
        }
        this.editingBooking = null; // Exit edit mode
        this.originalBookingState = null;
      },
      error => {
        console.error('Error updating booking:', error);
        alert('Failed to update booking. Please try again.');
      }
    );
  }
}

// Called when the "Cancel" button is clicked for a booking
onCancelBooking(): void {
  this.editingBooking = null; // Exit edit mode without saving changes
  this.originalBookingState = null;
}

// Helper to check if a specific booking is currently in edit mode
isBookingEditing(booking: Booking): boolean {
  return this.editingBooking?.bookingId === booking.bookingId;
}
getPropertyName(propertyId: string | number): string {
  // Ensure propertyId type matches what's stored in allPropertiesMap
  return this.allPropertiesMap.get(String(propertyId)) || 'Property Not Found';
}





fetchSellerProperties(): void {
  this.propertyService.getAll().subscribe(
    (properties: Property[]) => {
      // Filter properties only if userId is available
      this.sellerProperties = properties.filter(p => p.sellerId == this.userId);
      this.countOfProperties = this.sellerProperties.length;
      console.log("Seller Properties:", this.sellerProperties);
      console.log("Count of Properties:", this.countOfProperties);
    },
    error => {
      console.error("Error fetching properties:", error);
      // Handle error, e.g., show a message to the user
    }
  );
}




onEdit(property: Property): void {
  // Make a copy of the property to edit, to avoid directly modifying the displayed one
  this.editingProperty = { ...property };
  // Store the original state for potential cancellation
  this.originalPropertyState = { ...property };
}

onSave(property: Property): void {
  if (this.editingProperty && this.editingProperty.propertyId) { // Ensure propertyId exists for update
    // Call your service's update method
    this.propertyService.updateProperty(this.editingProperty.propertyId, this.editingProperty).subscribe(
      response => {
        console.log('Property updated successfully:', response);
        // Find the index of the updated property in the local array
        const index = this.sellerProperties.findIndex(p => p.propertyId === this.editingProperty?.propertyId);
        if (index !== -1) {
          // Update the property in the local array with the saved changes
          this.sellerProperties[index] = { ...this.editingProperty };
        }
        this.editingProperty = null; // Exit edit mode
        this.originalPropertyState = null; // Clear original state
      },
      error => {
        console.error('Error updating property:', error);
        alert('Failed to update property. Please try again.');
        // Optionally, revert to original state on error: this.onCancel();
      }
    );
  }
}

// Called when the "Cancel" button is clicked
onCancel(): void {
  this.editingProperty = null; // Exit edit mode
  this.originalPropertyState = null; // Clear original state
}

// Helper to check if a specific property is currently in edit mode
isEditing(property: Property): boolean {
  return this.editingProperty?.propertyId === property.propertyId;
}
// --- Inside your SellerdashboardComponent class ---

// Add this new method to handle property deletion
onDeleteProperty(propertyId:number): void {
  if (confirm('Are you sure you want to delete this property? This action cannot be undone.')) {
    this.propertyService.deleteProperty(propertyId).subscribe(
      response => {
        console.log('Property deleted successfully:', response);
        // Remove the deleted property from the local array to update the UI
        this.sellerProperties = this.sellerProperties.filter(p => p.propertyId !== propertyId);
        this.countOfProperties = this.sellerProperties.length; // Update the count
      },
      error => {
        console.error('Error deleting property:', error);
        alert('Failed to delete property. Please try again.');
      }
    );
  }
}
onDeleteBooking(bookingId: number): void {
  if (confirm('Are you sure you want to delete this booking? This action cannot be undone.')) {
    this.bookingService.deleteBooking(bookingId).subscribe(
      response => {
        console.log('Booking deleted successfully:', response);
        // Remove the deleted booking from the local array to update the UI
        this.buyerBookings = this.buyerBookings.filter(b => b.bookingId !== bookingId);
        this.countofbookings = this.buyerBookings.length; // Update the count
      },
      error => {
        console.error('Error deleting booking:', error);
        alert('Failed to delete booking. Please try again.');
      }
    );
  }
}
}
