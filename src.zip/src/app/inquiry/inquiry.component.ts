import { Component, OnInit } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { InquiryFormComponent } from '../inquiry-form/inquiry-form.component';
import { Inquiry } from '../../models/Inquiry.model';
import { InquiryService } from '../inquiry.service';
 
@Component({
  selector: 'app-inquiry',
  imports: [FormsModule,CommonModule],
  templateUrl: './inquiry.component.html',
  styleUrl: './inquiry.component.css'
})
export class InquiryComponent implements OnInit {
    inquiries: Inquiry[] = [];
    editingId: number | null = null;
    editableResponse: string = '';
   
    constructor(private service: InquiryService) {}
   
    ngOnInit(): void {
      this.loadInquiries();
    }
   
    loadInquiries() {
      this.service.getAll().subscribe(data => this.inquiries = data);
    }
   
    onInquiryCreated() {
      this.loadInquiries();
    }
   
    enableEdit(inquiry: Inquiry) {
      this.editingId = inquiry.inquiryId!;
      this.editableResponse = inquiry.response || '';
    }
   
    updateResponse(inquiry: Inquiry) {
      const updated: Inquiry = { ...inquiry, response: this.editableResponse };
      this.service.updateResponse(updated).subscribe(() => {
        this.editingId = null;
        this.loadInquiries();
      });
    }
   
    cancelEdit() {
      this.editingId = null;
    }
  }
 
 