import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { PropertiesComponent } from './properties/properties.component';

import { AddPropertyComponent } from './add-property/add-property.component';
import { UpdatePropertyComponent } from './update-property/update-property.component';
import { DeletePropertyComponent } from './delete-property/delete-property.component';
import { InquiryService } from './inquiry.service';
import { InquiryFormComponent } from './inquiry-form/inquiry-form.component';
import { InquiryComponent } from './inquiry/inquiry.component';

import { ɵNullViewportScroller } from '@angular/common';
import { ViewBookingComponent } from './view-bookings/view-bookings.component';
import { PropertySearchComponent } from './property-search/property-search.component';
import { ViewDetailComponent } from './view-detail/view-detail.component';
import { PaymentComponent } from './payment/payment.component';
import { BookingComponent } from './booking/booking.component';
import { SchedulevisitComponent } from './schedulevisit/schedulevisit.component';

import { SellerdashboardComponent } from './sellerdashboard/sellerdashboard.component';
import { BuyerdashboardComponent } from './buyerdashboard/buyerdashboard.component';
import {  buyerGuard, authGuard } from './auth.guard';
import { ManageAccountComponent } from './manage-account/manage-account.component';
import { FooterComponent } from './footer/footer.component';
import { AdminComponent } from './admin/admin.component';







export const routes: Routes = [
    { path: "login", component: LoginComponent },
    { path: "", component: LandingPageComponent },
    { path: "landingpage", component: LandingPageComponent },
    { path:"registration",component:RegistrationComponent},
    { path:"home",component:HomeComponent},
   
    // { path:"features",component:HomeHeaderComponent},
    { path:"property",component:PropertiesComponent},
    { path:"addProperty",component:AddPropertyComponent},
    { path:"updateProperty",component:UpdatePropertyComponent},
    { path:"deleteProperty",component:DeletePropertyComponent},
    { path:"inquiry",component:InquiryComponent},
    { path:"inquiryForm",component:InquiryFormComponent},
    { path:"bookings",component:BookingComponent},
    { path:"manageAccount",component:ManageAccountComponent},
    { path:"footer",component:FooterComponent},

    { path:"search",component:PropertySearchComponent},

    { path:"pay",component:PaymentComponent},
    { path:"properties",component:PropertiesComponent},
    // { path: 'book/:id', component:  ViewBookingComponent}
    { path:"viewBookings",component:ViewBookingComponent},
    { path:"scheduleVisit",component:SchedulevisitComponent},
  
    {path:"sellerDashboard",component:SellerdashboardComponent},
    {path:"buyerDashboard",component:BuyerdashboardComponent},
    {path:"admin",component:AdminComponent}





  
]
