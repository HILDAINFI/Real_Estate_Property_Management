import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-delete-property',
  imports: [FormsModule],
  templateUrl: './delete-property.component.html',
  styleUrl: './delete-property.component.css'
})
export class DeletePropertyComponent {
  
propertyId: number | null = null;
 deleteProperty(form: any) {
 if (form.valid && this.propertyId !== null) {
 console.log('Deleting property with ID:', this.propertyId);
// Call your service to delete the property
 }
}





}
