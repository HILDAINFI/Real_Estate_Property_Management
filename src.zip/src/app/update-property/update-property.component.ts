import { Component, OnInit } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { LoginService } from '../login.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Property } from '../add-property/add-property.component';



@Component({
  selector: 'update-property',
  imports: [FormsModule],
  templateUrl: './update-property.component.html',
  styleUrl: './update-property.component.css'
})
export class UpdatePropertyComponent {
 


    propertyId: number;
    propertyData: any = {};
  selectedProperty: any;
  properties: any;
  updateProp:Property={
    propertyId:null,
    title:'',
    location:'',
    sellerId:null,
    type:'',
    status:'',
    bathrooms:null,
    image:'',
    bedrooms:null,
    price:null,
    size:null
   

  }
  
    constructor(private route: ActivatedRoute, private propertyService: LoginService,private router:Router) {
      const navigation=this.router.getCurrentNavigation();
      this.propertyId=navigation?.extras.state?.['propertyId']
      // alert(this.propertyId)
    }
    editProperty(property: any) {
      this.selectedProperty = { ...property };
    }
    
    updateProperty() {
      const index = this.properties.findIndex(p => p.id === this.selectedProperty.id);
      if (index !== -1) {
        this.properties[index] = { ...this.selectedProperty };
      }
      this.selectedProperty = null;
    }
    
    cancelUpdate() {
      this.selectedProperty = null;
    }
    
  
    // ngOnInit(): void {
    //   this.propertyId = +this.route.snapshot.paramMap.get('id')!;
    //   this.fetchProperty();
    // }
  
    fetchProperty() {
      alert(this.propertyId)
      this.propertyService.getPropertyById(this.propertyId).subscribe({
        next: (data) => {
          this.propertyData = data;
        },
        error: (err) => {
          console.error('Failed to fetch property:', err);
        }
      });
    }
  
    propertyupdate(propertyForm:NgForm) {
      alert(this.propertyId)
      console.log(propertyForm.value)
      this.updateProp.propertyId=this.propertyId
      this.updateProp.title=propertyForm.value.title
      this.updateProp.location=propertyForm.value.location
      this.updateProp.sellerId=propertyForm.value.sellerId
      this.updateProp.price=propertyForm.value.price
      this.updateProp.type=propertyForm.value.type
      this.updateProp.status=propertyForm.value.status
      this.updateProp.bathrooms=propertyForm.value.bathrooms 
      this.updateProp.image=propertyForm.value.image
      this.updateProp.bedrooms=propertyForm.value.bedrooms
      this.updateProp.size=propertyForm.value.size 
      
      





      this.propertyService.updateProperty1(this.updateProp).subscribe({
        next: () => alert('Property updated successfully'),
        error: (err) => console.error('Update failed:', err)
      });
    }
    
  }
  