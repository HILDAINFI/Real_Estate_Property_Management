import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { OrderRequest } from '../models/OrderRequest.model';
 
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
 
@Injectable({
  providedIn: 'root'
})
export class OrderService {
 
  constructor(private http: HttpClient) { }
  baseUrl="http://localhost:8083/pg/"
 
  createOrder(order: { name: any; email: any; phone: any; amount: any; user_id:any }): Observable<any> {
    return this.http.post("http://localhost:8083/pg/createOrder", {
    customerName: order.name,
    email: order.email,
    phoneNumber: order.phone,
    amount: order.amount,
    userId: localStorage.getItem("userId")
    }, httpOptions);
}

getAllPayments():Observable<OrderRequest[]>{
  return this.http.get<OrderRequest[]>("http://localhost:8083/pg/getAllPayments");

}
 
} 