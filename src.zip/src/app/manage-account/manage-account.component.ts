import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // Required for *ngIf, etc.
import { FormsModule } from '@angular/forms'; // Optional: if you plan to add input fields later

@Component({
  selector: 'app-manage-account',
  standalone: true,
  imports: [CommonModule, FormsModule], // Include FormsModule if you foresee using ngModel
  templateUrl: './manage-account.component.html',
  styleUrls: ['./manage-account.component.css']
})
export class ManageAccountComponent implements OnInit {

  userName: string | null = null;
  userRole: string | null = null;
  userEmail: string | null = null; // Assuming email might be stored in localStorage as well
  userId: string | null = null;    // Assuming user ID might be stored

  // You can add a placeholder for an editable state if you plan to implement editing later
  // isEditing: boolean = false;

  constructor() { }

  ngOnInit(): void {
    // Retrieve user details from localStorage
    this.userName = localStorage.getItem('userName');
    this.userRole = localStorage.getItem('userRole');
    this.userEmail = localStorage.getItem('email'); // Assuming you store email
    this.userId = localStorage.getItem('userId');       // Assuming you store user ID

    // You can add more placeholder data if not available in localStorage
    if (!this.userEmail) {
      this.userEmail = 'user@example.com'; // Default placeholder email
    }
    if (!this.userId) {
      this.userId = 'N/A'; // Default placeholder ID
    }
  }

}