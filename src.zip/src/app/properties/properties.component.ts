import { Component, model, OnInit, TemplateRef } from '@angular/core';

import { HeaderComponent } from '../header/header.component';
import { FormsModule, NgForm, NgModel, ReactiveFormsModule, Validators } from '@angular/forms';
import { LoginService } from '../login.service';
import { Router, RouterLink } from '@angular/router';

import { pipe } from 'rxjs';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { Property } from '../../models/Property.model';
import { AddPropertyComponent } from '../add-property/add-property.component';
import { Booking } from '../../models/Booking.model';
import { HttpClient } from '@angular/common/http';
import { UpdatePropertyComponent } from '../update-property/update-property.component';
import { DeletePropertyComponent } from '../delete-property/delete-property.component';
import * as L from 'leaflet';

import { AfterViewInit } from '@angular/core';
import { FooterComponent } from '../footer/footer.component';

@Component({
  selector: 'app-properties',
  standalone:true,
  imports: [FormsModule,ReactiveFormsModule, CommonModule,AddPropertyComponent,UpdatePropertyComponent,FooterComponent],
  templateUrl: './properties.component.html',
  styleUrl: './properties.component.css'
})


  

export class PropertiesComponent implements OnInit {
  properties: any[] = [];
  searchQuery: string = ''
  isSeller: boolean = false;
  isBuyer: boolean = false;
  filteredProperties: any[] = [];
  currentPage = 1;
  Math = Math;
  booking:Booking
  itemsPerPage = 6;
  locationFilter = '';
  typeFilter = '';
  image='';
  error:any
 propertyId

  
  showAddProperty = false;
  showUpdateProperty=false;
  showDeleteProperty=false;
  selectedPropertyId: number;
  sellerId:number;
  str
 
  // New property for inline editing
  editingPropertyId: number | null = null;
  editedProperty: Property ;
  originalPropertyState: { propertyId: number; title: string; location: string; price: number; type: string; size: number; bedrooms: number; bathrooms: number; status: string; sellerId: number; imagePath?: string; };
  userId: string;
  userRole: string;

  // getImagePath(property: any): string {
  //   const type = property.type?.toLowerCase() || '';
  //   switch (type) {
  //     case 'villa':
  //       return 'assets/h3.png';
  //     case 'apartment':
  //       return 'assets/home2.jpg';
  //     case 'posegarden':
  //       return 'assets/home2.jpg';
  //     default:
  //       return 'h3.png';
  //   }
  // }
 




 
 

  updateProperty(propertyId:number)
  {
    this.router.navigate(['/updateProperty'],{state:{propertyId:propertyId}})
  }
toggleAddProperty() {
  this.showAddProperty = !this.showAddProperty;
}
toggleUpdateProperty() {
  this.showUpdateProperty = !this.showUpdateProperty;

}
toggleDeleteProperty() {
  this.showDeleteProperty = !this.showDeleteProperty;
}

  defaultImage = 'https://tse4.mm.bing.net/th/id/OIP.ehlBbJ8Wbq-PtPBqxPhOWgHaEo?rs=1&pid=ImgDetMain';

  constructor( private propertyService:LoginService,private router:Router, private client:HttpClient) {
    this.getAllProp();
    this. userId = localStorage.getItem('userId');
    this.userRole=localStorage.getItem('userRole')
    if(this.userRole=='BUYER'){
      this.isBuyer=true
    }
    
  }
  







  public getAllProp(){
    
      this.propertyService.getAll().subscribe(response=>this.handleSuccessfulResponse(response),
      error=>{this.error=error.message});
  }
  handleSuccessfulResponse(response){
         console.log(response)
         
         this.properties=response
    
      }

      buyProperty(propertyId: number, amount: number) {
        console.log(`Buying property ${propertyId} for ₹${amount}`);

        const headers = { 'Accept': 'application/json' };
        this.client.post(
          `http://localhost:9091/properties/buy/${propertyId}?amount=${amount}`,
          null,
          { headers, responseType: 'text' }
        ).subscribe({
          next: (response) => {
            console.log('Purchase successful:', response);
            alert(response);
            alert("Added to cart successfully!")
            this.getAllProp(); // Refresh property list
          },
          error: (err) => {
            console.error('Purchase failed:', err);
            alert('Purchase failed. Please try again.');
          }
        });
      }
      
      

      
      bookNow() {
        const propertyDetails = JSON.parse(localStorage.getItem('selectedProperty') || '{}');
        const userName = localStorage.getItem('userName');
        const email = localStorage.getItem('email');
         
       
      
        if (!propertyDetails || !userName || !email) {
          console.error('Missing booking or user details');
          return;
        }
      
        const bookingDetails = {
          property: propertyDetails,
          user: {
            name: userName,
            email: email
          }
        };
      
        this.makeBooking(bookingDetails);
      }
      


      makeBooking(bookingDetails: any) {
        // Example: Send booking to backend
        this.client.post('http://localhost:9091/bookings', bookingDetails).subscribe(response => {
          console.log('Booking successful:', response);
      
          // Send email notification
          const recipient = 'officialinfi36@gmail.com';
          const subject = 'InvoiceGenerated';
          const message = `Booking confirmed for ${bookingDetails.user.name} at ${bookingDetails.property.name}`;
      
          const emailUrl = `http://localhost:4009/email/send?recipient=${recipient}&subject=${subject}&message=${encodeURIComponent(message)}`;
      
          this.client.get(emailUrl).subscribe(emailResponse => {
            console.log('Email sent:', emailResponse);
            alert('Booking confirmed and email sent!');
          }, error => {
            console.error('Email failed:', error);
          });
      
        }, error => {
          console.error('Booking failed:', error);
        });
      }


      inquire(property: any): void {
        localStorage.setItem('sellerId', property.sellerId);
        localStorage.setItem('propertyId', property.propertyId);
        this.router.navigate(['/inquiryForm']); // Make sure this route exists
      }
      
      selectProperty(property: any): void {
        localStorage.setItem('selectedProperty', JSON.stringify(property));
        console.log('Selected property stored:', property);
      
        // Optional: Navigate to booking page
        this.router.navigate(['/bookings']);
      }
      
      
      


  ngOnInit(): void {
    
  const sellerId = localStorage.getItem('sellerId');
  const propertyId = localStorage.getItem('propertyId');

    const role = localStorage.getItem('userRole');
    this.isSeller = role === 'SELLER';
    
// this.form = this.fb.group({
//       sellerId: [{ value: sellerId, disabled: true }, Validators.required],
//       propertyId: [{ value: propertyId, disabled: true }, Validators.required],
//       message: ['', Validators.required]
//     });
  
    this.propertyService.getAll().subscribe(data => {
  
 this.applyFilters();
    });
  }



  

  applyFilters() {
    this.filteredProperties = this.properties.filter(p =>
      (!this.locationFilter || p.location.toLowerCase().includes(this.locationFilter.toLowerCase())) &&
      (!this.typeFilter || p.type.toLowerCase().includes(this.typeFilter.toLowerCase()))
    );
  }


  
  
  deleteProperty(propertyId: number) {
    if (confirm('Are you sure you want to delete this property?')) {
      this.propertyService.deleteProperty(propertyId).subscribe(() => {
        alert('Property deleted successfully');
        this.getAllProp(); // Refresh the list
      }, error => {
        console.error('Delete failed', error);
      });
    }
  }
  

  get paginatedProperties() {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    return this.filteredProperties.slice(start, start + this.itemsPerPage);
  }
 
 // --- Inline Editing Methods ---
 onEdit(property: Property): void {
  this.editingPropertyId = property.propertyId;
  // Create a deep copy to avoid modifying the original property directly until saved
  this.editedProperty = { ...property };
  this.showAddProperty = false; // Hide other forms
  this.showUpdateProperty = false; // Hide other forms
}

// onSave(property: Property): void {
//   if (this.editedProperty) {
//     // Call your API to update the property
//     this.propertyService.updateProperty(property.propertyId, this.editedProperty).subscribe(
//       response => {
//         console.log('Property updated successfully:', response);
//         // Update the original property in the local array
//         const index = this.properties.findIndex(p => p.propertyId === property.propertyId);
//         if (index !== -1) {
//           // FIX: Changed this.editingProperty to this.editedProperty
//           this.properties[index] = { ...this.editedProperty! }; // Update with the edited data
//           this.applyFilters(); // Re-apply filters to refresh view
//         }
//         // Exit edit mode
//       },
//       error => {
//         console.error('Error updating property:', error);
//         // Handle error, maybe show an error message
//       }
//     );
//   }
// }
// cancelEdit(): void {
//   this.editingProperty = null;
//   this.editingProperty = null;
// }


  pay(property: Property) {
    //property.status = "soldOut";
    this.selectedPropertyId = property.propertyId;
     // Only if you're routing
    // let pid = property.propertyId
    console.log("This is pid", this.selectedPropertyId);
    console.log("This is in pay funtion:",property.sellerId);
    // localStorage.setItem("propertyId", pid.toString());
    localStorage.setItem("price", property.price.toString());
    console.log("status is ", property.status);
    this.router.navigate(['/pay'],{state:{propId:this.selectedPropertyId,sellerId:property.sellerId}});
  }
 


}


