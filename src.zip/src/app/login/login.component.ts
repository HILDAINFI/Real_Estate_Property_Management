import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { User, UserServiceService } from '../user-service.service';
import { LoginService } from '../login.service';
import { jwtDecode } from 'jwt-decode';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'login',
  standalone: true,
  imports: [FormsModule,RouterLink,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  
isLoggedIn = false;
isSellerLoggedIn: boolean = false;

users:User[];
userRole:string
  userName: string;
  email: any;
  userId: any;
  name: any;
  id: any;
  userEmail: string;
  mail: any;

  

constructor(private router: Router,private userLogin:LoginService) {
  // LoginService.login().subscribe(response=>console.log(response))
}


  
   handleClose() {
     // Navigate to landing page
    this.router.navigate([""]);
    console.log("printed")
    
   // Update UI state
    this.isLoggedIn = true;

  }
  validate(form:NgForm){
    console.log("hiii",form.value.username)
    let username=form.value.username
    let password=form.value.password
    // this.router.navigate(["/home"])
    this.isSellerLoggedIn = this.userRole === 'seller';

    // this.userLogin.register(form.value).subscribe(reg=>console.log(reg))

    this.userLogin.login(form.value).subscribe(hilda=>{
      console.log(hilda);
      localStorage.setItem("JWT",hilda)
     

      const token=localStorage.getItem("JWT");
      if (!token) {
        console.error("No token found in localStorage");
        // You would typically handle this scenario, e.g., redirect to login
      } else {
        
        const decoded = jwtDecode<JwtPayload>(token);
console.log("Decoded token:", decoded);

this.userRole = decoded.roles ?? 'No role found';
this.userName = decoded.name ?? 'No user found';  // <-- Make sure this line is active
this.mail = decoded.mail ?? 'No email found';
this.userId = decoded.userId ?? 'No id found';

console.log("User Role:", this.userRole);
console.log("User Name:", this.userName);
console.log("User email:", this.mail);
console.log("User userId:", this.userId);

localStorage.setItem("userRole", this.userRole);
localStorage.setItem("userName", this.userName);
localStorage.setItem("email", this.mail);
localStorage.setItem("userId", this.userId);


      }
      
    });

      
 
      
    if(username===form.value.username&&password===form.value.password){
      this.router.navigate(["/home"])
      
    }
    

  }
 
    

}



interface JwtPayload {
  userId: string;
  mail: string;
  id: string;
  name: string;
  userName: string;
  email: string;
  roles?: string;
  // Add other fields if needed
}
