// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-view-detail',
//   imports: [],
//   templateUrl: './view-detail.component.html',
//   styleUrl: './view-detail.component.css'
// })
// export class ViewDetailComponent {

// }
import { Component } from '@angular/core';

import { HeaderComponent } from '../header/header.component';
import { FormsModule, NgForm, NgModel } from '@angular/forms';
import { LoginService } from '../login.service';
import { Router, RouterLink } from '@angular/router';

import { pipe } from 'rxjs';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { Property } from '../../models/Property.model'; 
import { AddPropertyComponent } from '../add-property/add-property.component';


@Component({
  selector: 'app-view-detail',
  imports: [FormsModule,RouterLink,CommonModule],
  templateUrl: './view-detail.component.html',
  styleUrl: './view-detail.component.css'
})
export class ViewDetailComponent {
  properties:Property[]
  error:any
  propertyId
  
trackByPropertyId(index: number, item: any) {
 return item.propertyId;
  }
  


  constructor(private getAllProperties:LoginService,private router:Router){
   this.getAllProp()
 
  }

  public getAllProp(){
    
    this.getAllProperties.getAll().subscribe(response=>this.handleSuccessfulResponse(response),
  error=>{this.error=error.message});


  }
  handleSuccessfulResponse(response){
    console.log(response)
    this.properties=response

  }
  
  property = {
    title: '',
    description: '',
    price: null,
    location: ''
  };

  onSubmit(form: any) {
    if (form.valid) {
      console.log('Property submitted:', this.property);
      // You can send this data to a backend service here
      form.resetForm();
    }
  }
  // deleteProperty(id:number)
  // {
  //   //confirm("Are you sure, you want to delete? "+id)
  //   this.getAllProperties.deleteProperty(id).subscribe(response=>console.log(response))
  //   alert("Travel package with id: "+id+" is successfully deleted")
  //   // window.location.reload();
   
 


bookProperty(){
  this.router.navigate(['/buy']);
}




}
