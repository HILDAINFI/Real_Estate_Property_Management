import { TestBed } from '@angular/core/testing';

import { SchedulevisitService } from './schedulevisit.service';

describe('SchedulevisitService', () => {
  let service: SchedulevisitService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SchedulevisitService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
