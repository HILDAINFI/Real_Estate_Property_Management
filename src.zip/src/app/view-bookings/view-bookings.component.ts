import { Component, NgModule } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, NgModel, Validators } from '@angular/forms';
import { BookingService } from '../booking.service';
import { Booking } from '../../models/Booking.model';
import { CommonModule, DatePipe } from '@angular/common';

@Component({
  selector: 'app-viewbooking',
  standalone:true,
  imports:[DatePipe,FormsModule,CommonModule],
  templateUrl: './view-bookings.component.html',
  styleUrls: ['./view-bookings.component.css']
})
export class ViewBookingComponent {
  bookingForm: FormGroup;
  bookings: Booking[] = [];
  selectedBooking?: Booking;
  bookingIdToView: number = 0;
  bookingIdToDelete: number = 0;
  bookingToUpdate: Partial<Booking> = {};
  editingBookingId: number | null = null;
editableStatus: string = '';


  constructor(private fb: FormBuilder, private bookingService: BookingService) {
    this.bookingForm = this.fb.group({
      sellerId: ['', Validators.required],
      propertyId: ['', Validators.required],
      status: ['Pending', Validators.required],
      date: [new Date().toISOString().substring(0, 10), Validators.required]
    });
  }
  ngOnInit() {
    this.loadAllBookings();
  }
  
  enableBookingEdit(booking: any) {
    this.editingBookingId = booking.bookingId;
    this.editableStatus = booking.status;
  }
  
  cancelBookingEdit() {
    this.editingBookingId = null;
    this.editableStatus = '';
  }
  
  saveBookingStatus(booking: any) {
    const updatedBooking = {
      ...booking,
      status: this.editableStatus
    };
  
    this.bookingService.updateBookingStatus(updatedBooking.bookingId, updatedBooking).subscribe({
      next: () => {
        alert('Booking status updated successfully');
        this.loadAllBookings(); // Refresh list
        this.cancelBookingEdit();
      },
      error: (err) => {
        console.error('Update failed', err);
      }
    });
  }
  confirmDeleteBooking(bookingId: number) {
    if (confirm('Are you sure you want to delete this booking?')) {
      this.bookingService.deleteBooking(bookingId).subscribe({
        next: () => {
          alert('Booking deleted successfully');
          this.loadAllBookings(); // Refresh the list
        },
        error: (err) => {
          console.error('Delete failed', err);
        }
      });
    }
  }
  
  submitForm() {
    if (this.bookingForm.valid) {
      const newBooking: Booking = this.bookingForm.value;
      this.bookingService.createBooking(newBooking).subscribe({
        next: () => {
          console.log('Booking created!');
          this.bookingForm.reset({ status: 'Pending', date: new Date().toISOString().substring(0, 10) });
          this.loadAllBookings();
        },
        error: (err) => console.error('Error creating booking:', err)
      });
    }
  }

  loadAllBookings() {
    this.bookingService.getAllBookings().subscribe({
      next: (data) => this.bookings = data,
      error: (err) => console.error('Error fetching bookings:', err)
    });
  }

  viewBookingById() {
    this.bookingService.getBooking(this.bookingIdToView).subscribe({
      next: (data) => this.selectedBooking = data,
      error: (err) => console.error('Error fetching booking:', err)
    });
  }

  updateBooking() {
    if (this.bookingToUpdate.bookingId) {
      this.bookingService.updateBookingStatus(
        this.bookingToUpdate.bookingId,
        this.bookingToUpdate as Booking
      ).subscribe({
        next: () => {
          console.log('Booking updated!');
          this.loadAllBookings();
        },
        error: (err) => console.error('Error updating booking:', err)
      });
    } else {
      console.warn('Booking ID is required to update a booking.');
    }
  }
  
  


  deleteBooking() {
    if (this.bookingIdToDelete) {
      this.bookingService.deleteBooking(this.bookingIdToDelete).subscribe({
        next: () => {
          console.log('Booking deleted!');
          this.loadAllBookings(); // Refresh the list
        },
        error: (err) => console.error('Error deleting booking:', err)
      });
    } else {
      console.warn('Please enter a valid Booking ID to delete.');
    }
  }
  
}
