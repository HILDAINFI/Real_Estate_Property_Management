import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { jwtDecode } from 'jwt-decode';
import { Property } from '../models/Property.model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  path="http://localhost:9091/auth/authenticate"
  path1="http://localhost:9091/auth/new"
  pathgetAllProperty="http://localhost:9091/properties/fetchAll"
  addProp="http://localhost:9091/properties/save"
  updateProp="http://localhost:9091/properties/update"
  deleteProp="http://localhost:9091/properties/deleteById"
  path_addBooking="http://localhost:9091/bookings/createbooking"
  searchPath="http://localhost:9091/properties"
  getAlls="http://localhost:9091/properties/fetchById"
  userId:number
  userRole:string

 

  constructor( private client:HttpClient) {
    
   }
   public login(login:User):Observable<string>{
    console.log("login....")
        return this.client.post(this.path,login,{responseType:'text'});
   }
   public register(register:data):Observable<String>{
    console.log("register...")
       return this.client.post(this.path1,register,{responseType:'text'});

   }
   // login.service.ts or property.service.ts
public buyProperty(propertyId: number, amount: number) {
  return this.client.post(`http://localhost:9091/properties/buy/${propertyId}?amount=${amount}`, null, {
    responseType: 'text' // because your backend returns a plain string
  });
}

   

   public addProperty(property: Property): Observable<string> {
    
    return this.client.post(this.addProp, property,{responseType:'text'});
  }

  public updateProperty(propertyId: number, updateProp: Property): Observable<Object>{
    
    return this.client.put(this.updateProp,{responseType:'text'})

  }
  public updateProperty1(updateProp:Property): Observable<Object>{
    
    return this.client.put(this.updateProp,updateProp,{responseType:'text'})

  }
  searchProperties(location: string, minPrice: number, maxPrice: number, type: string): Observable<Property[]> {
    const params = new HttpParams()
      .set('location', location)
      .set('minPrice', minPrice.toString())
      .set('maxPrice', maxPrice.toString())
      .set('type', type);
  
    return this.client.get<Property[]>(`${this.searchPath}/search`, { params });
  }
  



  

  public deleteProperty(propertyId:number):Observable<string>{
    return this.client.delete("http://localhost:9091/properties/deleteById/"+propertyId,{responseType:'text'})

  }
  public getPropertyById(propertyId:number){
    return this.client.get<Property>("http://localhost:9091/properties/fetchById" +propertyId)

  }


  
  

   public  getAll():Observable<Property[]>{

      return this.client.get<Property[]>(this.pathgetAllProperty) 
      

   }
}





export class User{
  username:String;
  password:String
}

export class data{
  name:String;
  email:string;
  password:string;
  roles:string

}

