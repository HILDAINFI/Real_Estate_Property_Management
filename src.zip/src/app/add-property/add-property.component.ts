import { Component } from '@angular/core';


import { FormsModule, NgForm } from '@angular/forms'; 
import { LoginService } from '../login.service';

@Component({
  selector: 'app-add-property',
  imports: [FormsModule],
  templateUrl: './add-property.component.html',
  styleUrl: './add-property.component.css'
})
export class AddPropertyComponent {

  pro:Property = {
    propertyId: 0,
    title: "",
    location: "",
    price: 0,
    type: "",
    size: 0,
    bedrooms: 0,
    bathrooms: 0,
    status: "",
    sellerId: Number(localStorage.getItem('userId')),
    image:""
   };

  constructor(private propertyService: LoginService) {}

  propertysave(form: NgForm) {
    console.log("ADD")
    console.log(form.value)
    if (form.valid) {
      this.propertyService.addProperty(this.pro).subscribe({
        next: (response) => {
          console.log('Property added successfully:', response);
          form.resetForm();
        },
        error: (err) => {
          console.error('Error adding property:', err);
        }
      });
    }
    alert(" Property Added Successfully!")
    // window.location.reload();
   
  }
  
}

export class   Property{
  propertyId:number;
  title:string;
    location:string;
     price:number;
    type:string;
     size:number;
     bedrooms:number;
     bathrooms:number;
     status:string;
     sellerId:number;
     image:string
  
 

   }

