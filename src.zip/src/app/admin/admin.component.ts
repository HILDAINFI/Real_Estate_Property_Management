import { Component, OnInit } from '@angular/core';
import { Property } from '../../models/Property.model';
import { OrderRequest } from '../../models/OrderRequest.model';
import { Booking } from '../../models/Booking.model';
import { Inquiry } from '../../models/Inquiry.model';
import { catchError, forkJoin, of } from 'rxjs';
import { LoginService } from '../login.service';
import { OrderService } from '../order.service';
import { BookingService } from '../booking.service';
import { InquiryService } from '../inquiry.service';
import { FormsModule } from '@angular/forms';
import { CommonModule, CurrencyPipe } from '@angular/common';

@Component({
  selector: 'app-admin',
  imports: [FormsModule,CommonModule],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent implements OnInit {




  properties: Property[] = [];
  payments: OrderRequest[] = [];
  bookings: Booking[] = [];
  inquiries: Inquiry[] = [];

  // Loading states
  isLoadingProperties = true;
  isLoadingPayments = true;
  isLoadingBookings = true;
  isLoadingInquiries = true;

  // Error states
  propertiesError: string | null = null;
  paymentsError: string | null = null;
  bookingsError: string | null = null;
  inquiriesError: string | null = null;

  constructor(
    private propertyService: LoginService, // Assuming LoginService handles properties
    private paymentService: OrderService, // You'll need to create this
    private bookingService: BookingService,
    private inquiryService: InquiryService
  ) { }

  ngOnInit(): void {
    this.loadAllData();
  }

  loadAllData(): void {
    this.isLoadingProperties = true;
    this.isLoadingPayments = true;
    this.isLoadingBookings = true;
    this.isLoadingInquiries = true;

    // Use forkJoin to fetch all data concurrently
    forkJoin({
      properties: this.propertyService.getAll().pipe(
        catchError(err => {
          console.error('Error loading properties:', err);
          this.propertiesError = 'Failed to load properties. Please try again.';
          return of([]); // Return an empty array on error to allow other observables to complete
        })
      ),
      payments: this.paymentService.getAllPayments().pipe(
        catchError(err => {
          console.error('Error loading payments:', err);
          this.paymentsError = 'Failed to load payments. Please try again.';
          return of([]); 
        })
      ),
      bookings: this.bookingService.getAllBookings().pipe(
        catchError(err => {
          console.error('Error loading bookings:', err);
          this.bookingsError = 'Failed to load bookings. Please try again.';
          return of([]);
        })
      ),
      inquiries: this.inquiryService.getAll().pipe( // Assuming this is correct for inquiries
        catchError(err => {
          console.error('Error loading inquiries:', err);
          this.inquiriesError = 'Failed to load inquiries. Please try again.';
          return of([]);
        })
      )
    }).subscribe({
      next: (data) => {
        this.properties = data.properties;
        this.payments = data.payments;
        this.bookings = data.bookings;
        this.inquiries = data.inquiries;
      },
      error: (err) => {
        // This error callback will only be hit if forkJoin itself fails (e.g., if one observable doesn't handle its own error)
        // With catchError on individual observables, this is less likely to be hit for HTTP errors.
        console.error('An unexpected error occurred during data loading:', err);
      },
      complete: () => {
        this.isLoadingProperties = false;
        this.isLoadingPayments = false;
        this.isLoadingBookings = false;
        this.isLoadingInquiries = false;
        console.log('All data loaded.');
      }
    });
  }

  // You can add more methods here, e.g., to navigate to detail pages
  viewPropertyDetails(propertyId: number): void {
    // Implement navigation, e.g., using Router
    console.log(`Navigating to property details for ID: ${propertyId}`);
    // this.router.navigate(['/admin/properties', propertyId]);
  }

  viewPaymentDetails(paymentId: number): void {
    console.log(`Navigating to payment details for ID: ${paymentId}`);
  }

  viewBookingDetails(bookingId: number): void {
    console.log(`Navigating to booking details for ID: ${bookingId}`);
  }

  viewInquiryDetails(inquiryId: number): void {
    console.log(`Navigating to inquiry details for ID: ${inquiryId}`);
  }

  // Helper to format date if needed (you might have a pipe for this)
  formatDate(dateString: string | Date): string {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString(); // Adjust format as needed
  }
}

  

