import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Booking } from '../models/Booking.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class BookingService {
  private baseUrl = 'http://localhost:9091/bookings';
 
  constructor(private http: HttpClient) {}
 
  getAllBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.baseUrl}/getAll`);
  }
 
  getBooking(id: number): Observable<Booking> {
    return this.http.get<Booking>(`${this.baseUrl}/getBookingById/${id}`);
  }
 
  createBooking(booking: Booking): Observable<string> {
return this.http.post(`${this.baseUrl}/createbooking`, booking, { responseType: 'text' });
  }
 
  updateBookingStatus(id: number, booking: Booking): Observable<Booking> {
    return this.http.put<Booking>(`${this.baseUrl}/updateBooking/${id}`, booking);
  }
 
  deleteBooking(id: number): Observable<string> {
    return this.http.delete(`${this.baseUrl}/delete/${id}`, { responseType: 'text' });
  }

  
}