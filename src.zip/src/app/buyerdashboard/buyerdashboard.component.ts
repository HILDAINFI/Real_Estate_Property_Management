import { Component, OnInit } from '@angular/core';
import { Booking } from '../../models/Booking.model';
import { BookingService } from '../booking.service';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OrderService } from '../order.service';
import { OrderRequest } from '../../models/OrderRequest.model';


@Component({
  selector: 'app-buyerdashboard',
  imports: [DatePipe,FormsModule,CommonModule],
  templateUrl: './buyerdashboard.component.html',
  styleUrl: './buyerdashboard.component.css'
})





export class BuyerdashboardComponent implements OnInit {




  buyerBookings: Booking[] = [];
  userName: string = '';
  email:string='';
  countofbookings
  buyerPayments: OrderRequest[];
  countofpayments: number = 0;
  order:any
  totAmount: number;
  


  constructor(private bookingService: BookingService,
    private paymentService: OrderService
    ) {}

  ngOnInit(): void {
    this.userName = localStorage.getItem('userName') || '';
    this.email = localStorage.getItem('email') || '';

    // Fetch all bookings and filter by userName
    this.bookingService.getAllBookings().subscribe((bookings: Booking[]) => {
      this.buyerBookings = bookings.filter(b => b.name === this.userName);
      console.log('Filtered Bookings:', this.buyerBookings);
        this.countofbookings=this.buyerBookings.length; 
    });
  

    

    this.paymentService.getAllPayments().subscribe((payments: OrderRequest[]) => {
      console.log("hello")
      this.buyerPayments = payments.filter(p => p.userId == localStorage.getItem('userId'));
      console.log('Filtered Payments:', this.buyerPayments);
      this.countofpayments = this.buyerPayments.length;
      this.totAmount=this.buyerPayments.reduce((sum, payment) => sum + Number(payment.amount), 0);
    });
    
    

  }

  onDeleteBooking(bookingId: number): void {
    if (confirm('Are you sure you want to delete this booking? This action cannot be undone.')) {
      this.bookingService.deleteBooking(bookingId).subscribe(
        response => {
          console.log('Booking deleted successfully:', response);
          // Remove the deleted booking from the local array to update the UI
          this.buyerBookings = this.buyerBookings.filter(b => b.bookingId !== bookingId);
          this.countofbookings = this.buyerBookings.length; // Update the count
        },
        error => {
          console.error('Error deleting booking:', error);
          alert('Failed to delete booking. Please try again.');
        }
      );
    }
  }
}
