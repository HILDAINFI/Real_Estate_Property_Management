import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { RegistrationComponent } from '../registration/registration.component';
import { Router, RouterLink } from '@angular/router';
import { AddPropertyComponent } from '../add-property/add-property.component';
import { InquiryFormComponent } from '../inquiry-form/inquiry-form.component';
import { PropertiesComponent } from '../properties/properties.component';
import { Property } from '../../models/Property.model';
import { LoginService } from '../login.service';
import { FooterComponent } from '../footer/footer.component';

@Component({
  selector: 'landing-page',
  imports: [RouterLink,FooterComponent],
  templateUrl: './landing-page.component.html',
  styleUrl: './landing-page.component.css'
})
export class LandingPageComponent {
  isLoggedIn:false
  carouselImages = [
    {
      src: 'assets/hall.jpg',
      alt: 'Modern Apartment',
      caption: 'Find Your Dream Home'
    },
    {
      src: 'assets/home2.jpg',
      alt: 'Luxury Villa',
      caption: 'Luxury Living Spaces'
    },
    {
      src: 'assets/homes.jpg',
      alt: 'City View',
      caption: 'Homes in Prime Locations'
    }
  ];

  
}

  

