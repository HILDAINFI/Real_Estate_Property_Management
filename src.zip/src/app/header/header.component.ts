import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { LandingPageComponent } from '../landing-page/landing-page.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HomeComponent } from '../home/home.component';

@Component({
  selector: 'header',
  standalone: true,
  imports: [RouterLink,FormsModule,CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  
  isLoggedIn = false;
  userRole
  isBuyer
  isSellerLoggedIn:boolean
  isBuyerLoggedIn:boolean
  isAdmin:boolean
  userName: string;
  constructor(private router: Router) {
    this.userRole=localStorage.getItem('userRole')
    this.userName=localStorage.getItem('userName')
    if(localStorage.getItem("JWT"))
    {
      this.isLoggedIn=true
      if(this.userRole=='ADMIN'){
        this.isAdmin=true
      }
    }
  }
  
 ngOnInit():void{
  this.isBuyer = this.userRole === 'BUYER';
 
 }
  menuclick() {
    if (!this.isLoggedIn) {
      alert("No Access. Please login first.");
    }
  }
  
  logout() {
    localStorage.clear();
    alert("Are You Sure want to logout!");
    this.router.navigate(['/landingpage']).then(() => {
      setTimeout(() => window.location.reload(), 100);
    });
  }
  
  handleClose() {
    // Navigate to landing page
    this.router.navigate(['/landingpage']);

    // Update UI state
    this.isLoggedIn = true;

    if(this.isLoggedIn){
      this.router.navigate(['/home'])
      window.location.reload();
    }
  }
}
