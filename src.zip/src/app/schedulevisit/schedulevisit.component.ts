import { Component } from '@angular/core';
import { Booking } from '../../models/Booking.model';
import { BookingService } from '../booking.service';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-schedulevisit',
  imports: [FormsModule,CommonModule],
  templateUrl: './schedulevisit.component.html',
  styleUrl: './schedulevisit.component.css'
})
export class SchedulevisitComponent {


  booking: Booking = {
    buyerId: 0,
    sellerId: 0,
    propertyId: 0,
    name: '',
    email: '',
    status: 'Scheduled',
   
  };

  message: string = '';

  constructor(private bookingService: BookingService) {}

  submitBooking() {
    this.bookingService.createBooking(this.booking).subscribe({
      next: (res) => {
        this.message = 'Visit scheduled successfully!';
        this.booking = {
          buyerId:0,
          sellerId: 0,
          propertyId: 0,
          name: '',
          email: '',
          status: 'Scheduled'
        };
      },
      error: (err) => {
        console.error(err);
        this.message = 'Failed to schedule visit.';
      }
    });
  }
}
