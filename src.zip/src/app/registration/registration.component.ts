import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { LoginService } from '../login.service';
 
@Component({
  selector: 'registration',
  imports: [ReactiveFormsModule, CommonModule,RouterLink],
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registrationForm: FormGroup;
  isLoggedIn=false;
 

 
  constructor(private fb: FormBuilder,private router:Router,private reg:LoginService) { }
 
  ngOnInit(): void {
    this.registrationForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(10)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      roles:['',Validators.required]
    }, );
  } 
 

 
  onSubmit(registrationForm:FormGroup) {
    if (this.registrationForm.valid) {
      console.log('Form Submitted!', this.registrationForm.value);
      this.reg.register(registrationForm.value).subscribe(response=>console.log(response))
      
      // localStorage.setItem("contactNumber",this.registrationForm.value.contactNumber)
      // localStorage.setItem("email",this.registrationForm.value.email)
      this.router.navigate(["/login"]);
    }
  }
     
  handleClose() {
    // Navigate to landing page
   this.router.navigate([""]);
   console.log("printed")
   
  // Update UI state
   this.isLoggedIn = true;
 }
  onReset(): void {
    this.registrationForm.reset();
  }

  registration(){
    this.router.navigate(["login"])
  }
}