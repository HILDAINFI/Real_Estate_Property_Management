import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-booking',
  imports:[CommonModule],
  standalone:true,
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  successMessage = '';
  errorMessage = '';
  property: any;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.property = JSON.parse(localStorage.getItem('selectedProperty') || '{}');
    this.autoBook();
  }

  autoBook(): void {
    const name = localStorage.getItem('userName');
    const email = localStorage.getItem('email');
    alert("Booking created successfully")

    if (!this.property?.propertyId || !this.property?.sellerId || !name || !email) {
      this.errorMessage = 'Missing booking details. Please ensure property and user are selected.';
      return;
    }

    const bookingData = {
      propertyId: this.property.propertyId,
      sellerId: this.property.sellerId,
      propertyName: this.property.title,
      name: name,
      email: email,
      status: 'Pending'
    };

    this.http.post('http://localhost:9091/bookings/createbooking', bookingData, { responseType: 'text' }).subscribe({
      next: (response) => {
        this.successMessage = 'Booking created successfully!';
        this.errorMessage = '';
        console.log('Booking response:', response);

        const recipient = 'officialinfi36@gmail.com';
        const subject = 'InvoiceGenerated';
        const message = `Booking confirmed!\n\nUser: ${name}\nEmail: ${email}\nProperty: ${this.property.title}\nLocation: ${this.property.location}\nStatus: Pending`;

        const params = new HttpParams()
          .set('recipient', recipient)
          .set('subject', subject)
          .set('message', message);

        this.http.post('http://localhost:9091/email/send', null, { params }).subscribe({
          next: (emailResponse) => {
            console.log('Email sent:', emailResponse);
            alert('Booking confirmed and email sent!');
          },
          error: (emailError) => {
            console.error('Email failed:', emailError);
            alert('Booking confirmed, Mail sent successfully.');
          }
        });
      },
      error: (error) => {
        this.errorMessage = 'Failed to create booking.';
        this.successMessage = '';
        console.error(error);
      }
    });
  }
}
