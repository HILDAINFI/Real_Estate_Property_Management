import { Component, NgModule } from '@angular/core';
import { Property } from '../../models/Property.model';
import { LoginService } from '../login.service';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm, NgModel } from '@angular/forms';

@Component({
  selector: 'app-property-search',
  imports: [CommonModule,FormsModule],
  templateUrl: './property-search.component.html',
  styleUrl: './property-search.component.css'
})
export class PropertySearchComponent {

  location = '';
  minPrice = 0;
  maxPrice = 10000000;
  type = '';
  properties: Property[] = [];

  constructor(private propertyService: LoginService) {}

  searchProperties() {
  
    this.propertyService.searchProperties(this.location, this.minPrice, this.maxPrice, this.type)
      .subscribe(data => {
        this.properties = data;
      });
  }
  
}
