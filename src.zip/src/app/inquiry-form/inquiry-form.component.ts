import { Component, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CommonModule } from '@angular/common';
import { InquiryService } from '../inquiry.service';
import { Inquiry } from '../../models/Inquiry.model';
import { InquiryComponent } from '../inquiry/inquiry.component';
 
@Component({
  selector: 'app-inquiry-form',
  imports: [FormsModule,ReactiveFormsModule,CommonModule],
  templateUrl: './inquiry-form.component.html',
  styleUrl: './inquiry-form.component.css'
})
export class InquiryFormComponent {

  form: FormGroup;
 
  inquiries: Inquiry[] = [];
    editingId: number | null = null;
    editableResponse: string = '';
  isSeller: boolean;
  isBuyer: boolean;
  role: string;
  loading:false
 
  constructor(private fb: FormBuilder, private service: InquiryService) {
   
this.form = this.fb.group({

    
      sellerId: ['', [Validators.required, Validators.min(1)]],
      propertyId: ['', [Validators.required, Validators.min(1)]],
      message: ['', Validators.required],
    });
  }
 
  submit() {
    const questionerId = localStorage.getItem('userId');
    const questionerRole = localStorage.getItem('userRole');
    console.log('Fetched from localStorage → userID:', questionerId, 'userRole:', questionerRole);
    if (!questionerId || !questionerRole) {
      alert('User not logged in or missing role information.');
      return;

      
    }
  
    if (this.form.valid) {
      const inquiry: Inquiry = {
        ...this.form.value,
        questionerId: Number(questionerId),
        questionerRole: questionerRole
      };
  

  
      // Create a summary message
      const summary = `
  Please confirm your inquiry submission:
  
  👤 Questioner ID: ${inquiry.questionerId}
  🔖 Role: ${inquiry.questionerRole}
  🏷️ Seller ID: ${inquiry.sellerId}
  🏠 Property ID: ${inquiry.propertyId}
  💬 Message: ${inquiry.message}
  
  Do you want to submit this inquiry?
      `;
  
      // Show confirmation dialog
      const confirmed = confirm(summary);
  
      if (confirmed) {
        this.service.createInquiry(inquiry).subscribe(() => {
          this.form.reset();
          this.loadInquiries();
        });
      }
    }
  }
  
  
  ngOnInit(): void {
    this.form = this.fb.group({
      sellerId: ['', Validators.required],
      propertyId: ['', Validators.required],
      message: ['', Validators.required]
    });
    const role = localStorage.getItem('userRole');
    this.isSeller = role === 'SELLER';
    this.isBuyer = role === 'BUYER';
    this.loadInquiries();
  }


  getInquiryById(id: number): void 
  {
    this.service.getInquiryById(1).subscribe({
      next: (data) => {
        console.log('Inquiry:', data);
        // You can assign it to a variable to display in the UI
      },
      error: (err) => {
        console.error('Error fetching inquiry:', err);
      }
    });
    
  }



 
  loadInquiries() {
    this.service.getAll().subscribe(data => this.inquiries = data);
  }
 
  onInquiryCreated() {
    this.loadInquiries();
  }
 
  enableEdit(inquiry: Inquiry) {
    this.editingId = inquiry.inquiryId!;
    this.editableResponse = inquiry.response || '';
  }
 
  updateResponse(inquiry: Inquiry) {
    const updated: Inquiry = { ...inquiry, response: this.editableResponse };
    this.service.updateResponse(updated).subscribe(() => {
      this.editingId = null;
      this.loadInquiries();
    });
  }
 
  cancelEdit() {
    this.editingId = null;
  }
}
