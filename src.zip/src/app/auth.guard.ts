import { CanActivateFn } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  if(localStorage.getItem("userRole")=='SELLER'){
    return true;
  }
  else{
  return false;
  }
};

export const buyerGuard: CanActivateFn = (route, state) => {
  if(localStorage.getItem("userRole")=='BUYER'){
    return true;
  }
  else{
  return false;
  }
};