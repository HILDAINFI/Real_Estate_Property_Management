// import { Injectable } from '@angular/core';

// import { Observable } from 'rxjs';
// import { HttpClient } from '@angular/common/http';
// import { OrderRequest } from '../models/orderRequest.model';
// // import { OrderRequest } from '../models/OrderRequest.model';



// @Injectable({
//   providedIn: 'root'
// })
// export class RazorpayServiceService {
 
//   private baseUrl = 'http://localhost:9091/pg';

//   constructor(private http: HttpClient) {}

//   createOrder(order: OrderRequest): Observable<any> {
//     return this.http.post(`${this.baseUrl}/createOrder`, order, { responseType: 'text' });
//   }
// }
