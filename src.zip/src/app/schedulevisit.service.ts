import { Injectable } from '@angular/core';
import { Booking } from '../models/Booking.model';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SchedulevisitService {

  private baseUrl = 'http://localhost:8080/bookings';

  constructor(private http: HttpClient) {}

  createBooking(booking: Booking): Observable<string> {
    return this.http.post(`${this.baseUrl}/createbooking`, booking, { responseType: 'text' });
  }
}


