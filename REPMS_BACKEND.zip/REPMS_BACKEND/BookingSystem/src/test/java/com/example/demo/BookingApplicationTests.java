package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import com.example.demo.dto.UserInfo;

import com.example.demo.exceptions.NoBookingFoundException;

import com.example.demo.feignclient.UserClient;
import com.example.demo.model.Booking;
import com.example.demo.repository.BookingRepository;
import com.example.demo.service.BookingServiceImpl;

@SpringBootTest
@ContextConfiguration(classes = { BookingSystem.class })
class BookingApplicationTests {

	@InjectMocks
	private BookingServiceImpl bookingService;

	@Mock
	private BookingRepository bookingRepository;

	@Mock
	private UserClient userClient;

	@Test
	void createBookingTest() {
		UserInfo userInfo = new UserInfo(1, "John Doe", "john.doe@example.com", "password", "User");
		Booking booking = new Booking();

		Mockito.when(bookingRepository.save(Mockito.any(Booking.class))).thenReturn(booking);
		Mockito.when(userClient.addNewUser(Mockito.any())).thenReturn("User saved");

		String result = bookingService.createBooking(booking);

		assertNotNull(result);
		assertEquals(booking, result);
		Mockito.verify(bookingRepository, Mockito.times(1)).save(booking);
		Mockito.verify(userClient, Mockito.times(1)).addNewUser(Mockito.any());
	}

	@Test
	void updateStatusTest() throws NoBookingFoundException {
		Booking booking = new Booking();
		Mockito.when(bookingRepository.save(Mockito.any(Booking.class))).thenReturn(booking);

		Booking result = bookingService.updateStatus(booking);

		assertNotNull(result);
		assertEquals(booking, result);
		Mockito.verify(bookingRepository, Mockito.times(1)).save(booking);
	}

	@Test
	void deleteBookingTest() throws NoBookingFoundException {
		int bookingId = 1;
		Mockito.when(bookingRepository.existsById(bookingId)).thenReturn(true);

		String result = bookingService.deleteBooking(bookingId);

		assertEquals("Booking deleted successfully", result);
		Mockito.verify(bookingRepository, Mockito.times(1)).deleteById(bookingId);
	}

	@Test
	void viewBookingTest() throws NoBookingFoundException {
		int bookingId = 1;
		Booking booking = new Booking();
		booking.setPropertyId(1);

		Mockito.when(bookingRepository.findById(bookingId)).thenReturn(Optional.of(booking));

		Booking result = bookingService.viewBooking(bookingId);

		assertNotNull(result);
		assertEquals(booking, result.getBookingId());

		Mockito.verify(bookingRepository, Mockito.times(1)).findById(bookingId);

	}
}
