package com.example.demo.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.dto.OrderRequest;
import com.example.demo.dto.OrderResponse;




	@FeignClient(name = "PAYMENT", path = "/payment")
public interface PaymentClient {
//	@PostMapping("/makePayment")
//	public  Payment processPayment(@RequestBody Payment payment);
//	@GetMapping("/getPaymentById/{pid}")
//	public  Payment viewPaymentById(@PathVariable("pid") int paymentId);
//	@GetMapping("/buyer/{bid}")
//	public   List<Payment> getPaymentByUserId(@PathVariable("bid") int buyerId);
		@RequestMapping(path = "/createOrder", method = RequestMethod.POST) // http://localhost:9090/pg/createOrder
		public OrderResponse createOrder(@RequestBody OrderRequest orderRequest);
	

}
