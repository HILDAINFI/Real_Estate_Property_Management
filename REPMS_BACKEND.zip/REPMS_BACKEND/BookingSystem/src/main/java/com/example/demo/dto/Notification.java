package com.example.demo.dto;

public class Notification {

}
