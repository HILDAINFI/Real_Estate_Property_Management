package com.example.demo.dto;


import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Property {
	@Id
	@GeneratedValue
	private int propertyId;
	private String title;
	private String location;
	private double price;
	private String type;
	private double size;
	private int bedrooms;
	private int bathrooms;
	private String status;
	private int sellerId;
	private String image;

//	@Lob
//@Column(name = "image", columnDefinition = "LONGBLOB")
//private byte[] image; // New field for storing image
//	
//
//@Transient
//private String base64Image; // Used only for receiving image in JSON
//
	}
