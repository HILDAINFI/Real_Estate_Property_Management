
package com.example.demo.exceptions;

public class NoPropertyFoundException extends RuntimeException {
    public NoPropertyFoundException(String message) {
        super(message);
    }
}
