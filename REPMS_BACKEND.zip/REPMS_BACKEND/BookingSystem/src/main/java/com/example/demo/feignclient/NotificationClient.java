package com.example.demo.feignclient;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

 
@FeignClient(name = "NOTIFICATION", path = "/email")
 
public interface NotificationClient {
	@PostMapping("/send")
	public String sendEmail(@RequestParam String recipient, @RequestParam String subject,
			@RequestParam String message);
 
}
 
 