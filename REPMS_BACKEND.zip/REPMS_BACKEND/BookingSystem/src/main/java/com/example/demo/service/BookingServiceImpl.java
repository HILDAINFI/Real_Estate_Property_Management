package com.example.demo.service;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.UserInfo;
import com.example.demo.exceptions.NoBookingFoundException;
import com.example.demo.exceptions.NoPropertyFoundException;
import com.example.demo.feignclient.NotificationClient;
import com.example.demo.feignclient.UserClient;
import com.example.demo.model.Booking;
import com.example.demo.repository.BookingRepository;
 
@Service
public class BookingServiceImpl implements BookingService {
	@Autowired
	private BookingRepository bookingRepository;
	@Autowired
	UserClient userClient;
	@Autowired
	NotificationClient notificationClient;
 
	public String createBooking(Booking booking) {
		

		booking.setStatus("Pending");
		UserInfo ui = userClient.getUserById(booking.getSellerId());
		if(ui.getId()==booking.getSellerId()) {
			bookingRepository.save(booking);
			notificationClient.sendEmail("officialinfi36@gmail.com", "invoice generated", "confirmed");
		}
		if (ui == null || ui.getId() != booking.getSellerId()) {
			throw new NoPropertyFoundException("No property found for seller ID: " + booking.getSellerId());
			}

		



		return "Status for bookingId:"+booking.getBookingId()+" is: "+booking.getStatus();
	}
 
	@Override
	public Booking updateStatus(Booking booking) throws NoBookingFoundException {
		UserInfo ui = userClient.getUserById(booking.getSellerId());
		if(ui.getId()==booking.getSellerId()) {
			bookingRepository.save(booking);
		}
		return booking;
	}
 
	@Override
	public String deleteBooking(int bookingId) throws NoBookingFoundException {
 
		if (!bookingRepository.existsById(bookingId)) {
			throw new NoBookingFoundException("No booking found with ID: " + bookingId);
		}
		bookingRepository.deleteById(bookingId);
		return "Booking deleted successfully";
	}
 
	@Override
	public Booking viewBooking(int bookingId) throws NoBookingFoundException {
		Booking book = bookingRepository.findById(bookingId).get();
//		int userno=book.getUserId();
//		User  user = userClient.getUserById(userno); 
		//int propertyId = book.getPropertyId();
	//UserPropertyResponseDTO property = propertyClient.getProperty(propertyId);
		//UserBookingResponseDTO responseDTO = new UserBookingResponseDTO(book, property);
		return book;
	}
 
	@Override
	public List<Booking> getAll() {
		return bookingRepository.findAll();
	}
 
}