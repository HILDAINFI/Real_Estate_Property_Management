package com.example.demo.service;

import java.util.List;

import com.example.demo.exceptions.NoBookingFoundException;
import com.example.demo.model.Booking;

public interface BookingService {
	public abstract String createBooking(Booking booking);
	public abstract Booking updateStatus(Booking booking) throws NoBookingFoundException;
	public abstract String deleteBooking(int bookingId) throws NoBookingFoundException;
	public abstract Booking viewBooking(int bookingId) throws NoBookingFoundException;
	public abstract List<Booking> getAll();
}
