package com.example.demo.model;

public enum BookingStatus {
	PENDING, CONFIRMED, DECLINED;
}
