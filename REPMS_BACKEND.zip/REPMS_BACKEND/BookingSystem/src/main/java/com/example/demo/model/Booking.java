//package com.example.demo.model;
//import java.time.LocalDateTime;
//
//import org.hibernate.annotations.CreationTimestamp;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.Id;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Entity
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class Booking {
//    @Id
//    @GeneratedValue
//    private int bookingId;
//
//    private int userId;
//    private int  propertyId;
//    private String status;
//    @CreationTimestamp
//    private LocalDateTime date;
//
////    @Enumerated(EnumType.STRING)
//}
//
package com.example.demo.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {
    @Id
    @GeneratedValue
    private int bookingId;
    @NotNull(message = "User ID cannot be null")
    private int sellerId;
    @NotNull(message = "Property ID cannot be null")
    private int propertyId;
    private String name;
    private String email;
    @NotNull(message = "Status cannot be null")
    @Size(max = 50, message = "Status cannot exceed 50 characters")
    private String status;
//    @CreationTimestamp
//    private LocalDateTime date;
    private LocalDateTime date;
    @PreUpdate
    protected void onUpdate()
    {
    	this.date=LocalDateTime.now();
    }
    @PrePersist
    protected void onCreate()
    {
    	this.date=LocalDateTime.now();
    }
    
    
    

}
