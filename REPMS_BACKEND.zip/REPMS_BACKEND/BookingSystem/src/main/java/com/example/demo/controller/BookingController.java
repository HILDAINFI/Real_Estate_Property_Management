package com.example.demo.controller;
 
import java.util.List;

 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
 
import com.example.demo.exceptions.NoBookingFoundException;
import com.example.demo.model.Booking;
import com.example.demo.service.BookingService;

import jakarta.validation.Valid;
 
@RestController
@RequestMapping("/bookings")
public class BookingController {
	@Autowired
	private BookingService bookingService;
 
	@PostMapping("/createbooking")
	public String createBooking(@RequestBody Booking booking) {
		return bookingService.createBooking(booking);
	}
 
	@PutMapping("updateBooking/{id}")
	public Booking updateStatus(@PathVariable("id") int BookingId, @Valid @RequestBody Booking booking)
			throws NoBookingFoundException {
		return bookingService.updateStatus(booking);
	}
 
	@DeleteMapping("/delete/{bid}")
	public String deleteBooking(@PathVariable("bid") int bookingId) throws NoBookingFoundException {
		return bookingService.deleteBooking(bookingId);
	}
 
	@GetMapping("/getBookingById/{bid}")
	public Booking getBooking(@PathVariable("bid") int bookingId) throws NoBookingFoundException {
		return bookingService.viewBooking(bookingId);
	}
	@GetMapping("/getAll")
	public List<Booking> getAll() {
		return bookingService.getAll();
	}
 
}