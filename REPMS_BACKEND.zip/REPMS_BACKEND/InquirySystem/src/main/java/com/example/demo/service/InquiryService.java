package com.example.demo.service;

import java.util.List;

import com.example.demo.exceptions.InquiryNotFoundException;
import com.example.demo.model.Inquiry;

public interface InquiryService {
	public abstract String createInquiry(Inquiry inquiry);

	public abstract String updateStatus(int inquiryId, String status) throws InquiryNotFoundException;

	public abstract Inquiry viewInquiry(int inquiryId) throws InquiryNotFoundException;

	public abstract List<Inquiry> getAll();
}
