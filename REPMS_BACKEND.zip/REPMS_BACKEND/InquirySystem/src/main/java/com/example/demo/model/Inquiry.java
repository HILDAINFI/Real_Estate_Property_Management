package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Inquiry {
	@Id
	@GeneratedValue
	private int inquiryId;
	private int questionerId;
	private String questionerRole;
	private int sellerId;
	private int propertyId;
	private String message;
	private String response;
}
