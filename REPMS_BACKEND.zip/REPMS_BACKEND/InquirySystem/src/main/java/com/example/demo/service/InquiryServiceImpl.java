package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.UserInfo;
import com.example.demo.exceptions.InquiryNotFoundException;
import com.example.demo.feignclient.UserClient;
import com.example.demo.model.Inquiry;
import com.example.demo.repository.InquiryRepository;

@Service
public class InquiryServiceImpl implements InquiryService {
	@Autowired
	private InquiryRepository inquiryRepository;
	@Autowired
	UserClient userClient;

	public String createInquiry(Inquiry inquiry) {
		inquiry.setResponse("Our Service provider will reach You");
		UserInfo ui = userClient.getUserById(inquiry.getSellerId());
		if(ui.getId()==inquiry.getSellerId()) {
			inquiryRepository.save(inquiry);
		}
		return "Your Inquiry ID is :"+inquiry.getInquiryId()+"\nOur Response is : "+inquiry.getResponse();
		
	}

	public String updateStatus(int inquiryId, String response) throws InquiryNotFoundException {

		Inquiry inquiry = inquiryRepository.findById(inquiryId)
				.orElseThrow(() -> new InquiryNotFoundException("Inquiry not found with ID: " + inquiryId));

		inquiry.setResponse(response); // assuming status is a String field
		inquiryRepository.save(inquiry);
		return "Your inquiry is : "+inquiry.getMessage()+"\nOur response is : "+inquiry.getResponse();
	}

	@Override
	public Inquiry viewInquiry(int inquiryId) throws InquiryNotFoundException {
		Inquiry inquiry = inquiryRepository.findById(inquiryId).get(); 
		int propertyId = inquiry.getPropertyId();
		return inquiry;
	}

	@Override
	public List<Inquiry> getAll() {

		return inquiryRepository.findAll();
	}

}
