package com.example.demo.exceptions;

public class NoSellerFoundException extends RuntimeException {
    public NoSellerFoundException(String message) {
        super(message);
    }
}
