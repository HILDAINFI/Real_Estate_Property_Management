package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.exceptions.InquiryNotFoundException;
import com.example.demo.model.Inquiry;
import com.example.demo.service.InquiryServiceImpl;

@RestController
@RequestMapping("/inquiries")
public class InquiryController {
	@Autowired
	private InquiryServiceImpl inquiryService;

	@PostMapping("/create")
	public String createInquiry(@RequestBody Inquiry inquiry) {
		String createdInquiry = inquiryService.createInquiry(inquiry);
		return createdInquiry;
	}

	@PutMapping("/updateStatus")
	public String updateInquiryStatus(@RequestBody Inquiry inquiry)
			throws InquiryNotFoundException {
		return inquiryService.updateStatus(inquiry.getInquiryId(), inquiry.getResponse());
	}

	@GetMapping("/get/{iid}")
	public Inquiry getInquiry(@PathVariable("iid") int inquiryId) throws InquiryNotFoundException {
		return inquiryService.viewInquiry(inquiryId);
	}

	@GetMapping("/getAll")
	public List<Inquiry> getAll() {
		return inquiryService.getAll();
	}
}
