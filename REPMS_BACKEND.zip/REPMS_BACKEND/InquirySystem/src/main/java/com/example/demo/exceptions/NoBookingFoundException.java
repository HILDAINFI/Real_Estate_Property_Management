
package com.example.demo.exceptions;

public class NoBookingFoundException extends RuntimeException {

	public NoBookingFoundException(String message) {
		super(message);
	}
}