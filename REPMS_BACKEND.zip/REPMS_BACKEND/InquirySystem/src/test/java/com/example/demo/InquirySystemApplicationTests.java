package com.example.demo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.dto.UserInfo;
import com.example.demo.exceptions.InquiryNotFoundException;
import com.example.demo.feignclient.UserClient;
import com.example.demo.model.Inquiry;
import com.example.demo.repository.InquiryRepository;
import com.example.demo.service.InquiryServiceImpl;
@SpringBootTest
class InquiryServiceImplTest {

    @Mock
    private InquiryRepository inquiryRepository;

    @Mock
    private UserClient userClient;

    @InjectMocks
    private InquiryServiceImpl inquiryService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateInquiry() {
        Inquiry inquiry = new Inquiry();
        inquiry.setInquiryId(1);
        inquiry.setSellerId(100);
        inquiry.setMessage("Need more info");

        UserInfo userInfo = new UserInfo();
        userInfo.setId(100);

        when(userClient.getUserById(100)).thenReturn(userInfo);
        when(inquiryRepository.save(inquiry)).thenReturn(inquiry);

        String result = inquiryService.createInquiry(inquiry);

        assertTrue(result.contains("Your Inquiry ID is :1"));
        verify(inquiryRepository, times(1)).save(inquiry);
    }

    @Test
    void testUpdateStatus() throws InquiryNotFoundException {
        Inquiry inquiry = new Inquiry();
        inquiry.setInquiryId(1);
        inquiry.setMessage("Initial message");

        when(inquiryRepository.findById(1)).thenReturn(Optional.of(inquiry));
        when(inquiryRepository.save(inquiry)).thenReturn(inquiry);

        String result = inquiryService.updateStatus(1, "Updated response");

        assertTrue(result.contains("Updated response"));
        verify(inquiryRepository).save(inquiry);
    }

    @Test
    void testUpdateStatusThrowsException() {
        when(inquiryRepository.findById(999)).thenReturn(Optional.empty());

        assertThrows(InquiryNotFoundException.class, () -> {
            inquiryService.updateStatus(999, "Response");
        });
    }

    @Test
    void testViewInquiry() throws InquiryNotFoundException {
        Inquiry inquiry = new Inquiry();
        inquiry.setInquiryId(1);
        inquiry.setPropertyId(200);

        when(inquiryRepository.findById(1)).thenReturn(Optional.of(inquiry));

        Inquiry result = inquiryService.viewInquiry(1);

        assertEquals(200, result.getPropertyId());
    }

    @Test
    void testGetAll() {
        Inquiry inquiry1 = new Inquiry();
        Inquiry inquiry2 = new Inquiry();

        when(inquiryRepository.findAll()).thenReturn(Arrays.asList(inquiry1, inquiry2));

        List<Inquiry> result = inquiryService.getAll();

        assertEquals(2, result.size());
    }
}
