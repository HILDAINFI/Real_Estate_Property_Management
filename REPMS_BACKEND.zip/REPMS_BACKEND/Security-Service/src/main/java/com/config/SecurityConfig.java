package com.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.filter.JwtAuthFilter;

import jakarta.ws.rs.HttpMethod;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
	@Autowired
	private JwtAuthFilter authFilter;

	// authentication
	@Bean
	UserDetailsService userDetailsService() {
		return new UserInfoUserDetailsService();
	}



	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
	    CorsConfiguration configuration = new CorsConfiguration();
	    configuration.setAllowedOrigins(List.of("http://localhost:4200"));
	    configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE"));
	    configuration.setAllowedHeaders(List.of("*"));
	    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	    source.registerCorsConfiguration("/**", configuration);
	    return source;
	}

	
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		
        return http.csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/auth/**").permitAll()
                
                // ADMIN access
                .requestMatchers( "/properties/**","/searchProperties/**", "/bookings/**", "/inquiries/**", "/payment/**", "/search/**", "/recommendations/**")
                    .hasRole("ADMIN")
 
                // AGENT access 
                .requestMatchers(HttpMethod.GET, "/bookings/**","/searchProperties/**", "/properties/**", "/inquiries/**","/search/**","/payment/**").hasRole("AGENT")
                .requestMatchers(HttpMethod.POST,"/properties/**","/bookings/**","/search/**","/inquiries/**", "/payment/**").hasRole("AGENT")
                .requestMatchers(HttpMethod.PUT, "/properties/**","/inquiries/**","/bookings/**").hasRole("AGENT")
                .requestMatchers(HttpMethod.DELETE, "/properties/**","/bookings/**","/inquiries/**").hasRole("AGENT")
 
                // BUYER access
                .requestMatchers(HttpMethod.GET, "/inquiries/**","/bookings/**","/searchProperties/**", "/properties/**","/search/**" ,"/payment/**").hasRole("BUYER")
//                .requestMatchers(HttpMethod.PUT,   "/inquiries/**").hasRole("BUYER")
                .requestMatchers(HttpMethod.POST,"/inquiries/**","/payment/**").hasRole("BUYER")
                .requestMatchers(HttpMethod.DELETE, "/inquiries/**", "/bookings/**").hasRole("BUYER")
                
                // SELLER access
                .requestMatchers(HttpMethod.GET, "/inquiries/**","/bookings/**","/searchProperties/**", "/properties/**", "/search/**","/recommendations/**").hasRole("SELLER")
                .requestMatchers(HttpMethod.PUT,  "/bookings/**","/bookings/**","/inquiries/**").hasRole("SELLER")
                .requestMatchers(HttpMethod.POST, "/properties/**","/inquiries/**","/payment/**").hasRole("SELLER")
                .requestMatchers(HttpMethod.DELETE, "/inquiries/**", "/bookings/**","/properties/**").hasRole("SELLER")
 
                .anyRequest().authenticated()
            )
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authenticationProvider(authenticationProvider())
            .addFilterBefore(authFilter, UsernamePasswordAuthenticationFilter.class)
            .build();
    }


	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	AuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
		authenticationProvider.setUserDetailsService(userDetailsService());
		authenticationProvider.setPasswordEncoder(passwordEncoder());
		return authenticationProvider;
	}

	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		return config.getAuthenticationManager();
	}

}
