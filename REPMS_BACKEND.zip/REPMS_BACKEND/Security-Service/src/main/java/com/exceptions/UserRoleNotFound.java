package com.exceptions;

public class UserRoleNotFound extends Exception{
	
	public UserRoleNotFound(String message) {
		super(message);
	}

}
